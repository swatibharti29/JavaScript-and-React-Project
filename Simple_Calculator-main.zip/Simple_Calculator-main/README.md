# Simple_Calculator

A simple calculator built using HTML and JavaScript, styled with fun emojis to make math more enjoyable.

 Features:-

- Basic arithmetic operations: ➕ ➖ ✖️ ➗
- Clear display (AC), backspace 🔙, and dot 🔸 support
- Emoji-based button layout for a playful UI
- Responsive display that updates in real-time
  
Tech Stack

- HTML — for structure  
- JavaScript — for logic  
- (No external CSS or libraries used)


